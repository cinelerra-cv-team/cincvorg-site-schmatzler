!#/bin/bash
cp -a /home/user/install/cinelerra-2.1.5/cinelerra-theme-helper/backup/cinelerra /home/user/install/cinelerra-2.1.5/cinelerra-theme-helper/backup/plugins /home/user/install/cinelerra-2.1.5/cinelerra-theme-helper/backup/redo.sh /home/user/install/cinelerra-2.1.5/cinelerra-theme-helper/../../
